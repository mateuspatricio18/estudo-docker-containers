USE escola;

CREATE TABLE IF NOT EXISTS estudantes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    curso VARCHAR(50) NOT NULL,
    data_matricula DATE NOT NULL,
    ativo BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS disciplinas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    codigo VARCHAR(20) UNIQUE NOT NULL,
    carga_horaria INT NOT NULL,
    professor VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS notas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    estudante_id INT,
    disciplina_id INT,
    nota DECIMAL(5,2),
    data_avaliacao DATE,
    FOREIGN KEY (estudante_id) REFERENCES estudantes(id),
    FOREIGN KEY (disciplina_id) REFERENCES disciplinas(id)
);

INSERT IGNORE INTO estudantes (nome, email, curso, data_matricula) VALUES
('Ana Silva', 'ana@exemplo.com', 'Informática', '2024-02-01'),
('João Santos', 'joao@exemplo.com', 'Informática', '2024-02-01'),
('Maria Oliveira', 'maria@exemplo.com', 'Administração', '2024-02-15');

INSERT IGNORE INTO disciplinas (nome, codigo, carga_horaria, professor) VALUES
('Programação Web', 'PROG001', 80, 'Prof. Carlos'),
('Banco de Dados', 'BD001', 60, 'Prof. Ana'),
('Sistemas Operacionais', 'SO001', 70, 'Prof. Roberto');

INSERT INTO notas (estudante_id, disciplina_id, nota, data_avaliacao)
SELECT 1, 1, 8.5, '2024-03-15'
WHERE NOT EXISTS (SELECT 1 FROM notas WHERE estudante_id=1 AND disciplina_id=1);

INSERT INTO notas (estudante_id, disciplina_id, nota, data_avaliacao)
SELECT 1, 2, 9.0, '2024-03-20'
WHERE NOT EXISTS (SELECT 1 FROM notas WHERE estudante_id=1 AND disciplina_id=2);

INSERT INTO notas (estudante_id, disciplina_id, nota, data_avaliacao)
SELECT 2, 1, 7.5, '2024-03-15'
WHERE NOT EXISTS (SELECT 1 FROM notas WHERE estudante_id=2 AND disciplina_id=1);

INSERT INTO notas (estudante_id, disciplina_id, nota, data_avaliacao)
SELECT 3, 3, 8.0, '2024-03-25'
WHERE NOT EXISTS (SELECT 1 FROM notas WHERE estudante_id=3 AND disciplina_id=3);

SELECT 'Dados inseridos com sucesso!' AS status;
