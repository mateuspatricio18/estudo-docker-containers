# Evidências

Os prints precisam ser gerados durante a execução real das tarefas.

- `tarefa1.png` — container Ubuntu/hello-world funcionando.
- `tarefa2.png` — aplicação Nginx funcionando em `localhost:8080`.
- `tarefa3.png` — logs/scripts do MySQL funcionando.
- `tarefa4.png` — aplicação Flask + MySQL funcionando em `localhost:8000`.

Substitua este arquivo pelos prints correspondentes quando executar as tarefas.
