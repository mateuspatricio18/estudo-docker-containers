# Bancos de Dados em Docker

## MySQL Container
- **Imagem:** mysql:8.0
- **Porta:** 3306
- **Banco:** escola
- **Usuário:** aluno
- **Senha:** aluno123

## Scripts Criados
- `scripts/criar-tabelas.sql` - Estrutura e dados iniciais do banco
- `scripts/backup-banco.sh` - Script de backup
- `scripts/monitorar-mysql.sh` - Monitoramento do container MySQL

## Comandos Úteis

```bash
docker exec -it mysql-estudos mysql -u aluno -paluno123 escola
docker logs mysql-estudos
./scripts/backup-banco.sh
docker stop mysql-estudos
docker start mysql-estudos
```
