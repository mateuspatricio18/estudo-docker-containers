# Tarefa 4 - Docker Compose

## O que é Docker Compose?
Docker Compose é uma ferramenta para definir e executar aplicações Docker com múltiplos containers. Por meio de um arquivo YAML, podemos configurar serviços, redes, volumes e variáveis de ambiente.

## Serviços Criados

### `app`
- Aplicação web em Python/Flask.
- Construída a partir do `Dockerfile`.
- Disponível na porta 8000.
- Conecta-se ao banco pelo hostname `db`.

### `db`
- Utiliza a imagem `mysql:8.0`.
- Banco chamado `escola`.
- Utiliza o volume nomeado `db_data`.
- Executa o script SQL na primeira inicialização.

## Vantagens observadas
- **Simplicidade:** um único comando pode iniciar todo o ambiente.
- **Configuração centralizada:** os serviços ficam definidos no `docker-compose.yml`.
- **Rede interna:** os containers se comunicam pelos nomes dos serviços.
- **Reprodutibilidade:** o ambiente pode ser recriado por outras pessoas com Docker.

## Comandos utilizados

```bash
docker compose up --build -d
docker compose ps
docker compose logs app
docker compose logs db
docker compose stop
docker compose start
docker compose down
```

## Screenshot
Adicione após executar:

`![Aplicação rodando com Docker Compose](screenshot-compose-app.png)`
