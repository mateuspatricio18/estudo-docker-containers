from flask import Flask, render_template, request, redirect, url_for
import mysql.connector
import os
import time

app = Flask(__name__)

def get_db_connection():
    retries = 10
    while retries > 0:
        try:
            conn = mysql.connector.connect(
                host=os.getenv("DB_HOST", "db"),
                user=os.getenv("DB_USER", "aluno"),
                password=os.getenv("DB_PASSWORD", "aluno123"),
                database=os.getenv("DB_NAME", "escola")
            )
            return conn
        except mysql.connector.Error as err:
            print(f"Erro ao conectar ao banco de dados: {err}")
            retries -= 1
            time.sleep(3)
    return None

@app.route("/")
def index():
    conn = get_db_connection()
    if conn is None:
        return "<h1>Erro: Não foi possível conectar ao banco de dados.</h1>", 500

    cursor = None
    try:
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM estudantes ORDER BY id DESC")
        estudantes = cursor.fetchall()
        return render_template("index.html", estudantes=estudantes)
    except Exception as e:
        return f"<h1>Erro ao consultar o banco:</h1><p>{e}</p>", 500
    finally:
        if cursor:
            cursor.close()
        conn.close()

@app.route("/adicionar", methods=["POST"])
def adicionar_estudante():
    nome = request.form["nome"]
    email = request.form["email"]
    curso = request.form["curso"]

    conn = get_db_connection()
    if conn is None:
        return "<h1>Erro ao conectar ao banco de dados.</h1>", 500

    cursor = None
    try:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO estudantes (nome, email, curso, data_matricula) "
            "VALUES (%s, %s, %s, CURDATE())",
            (nome, email, curso)
        )
        conn.commit()
        return redirect(url_for("index"))
    except Exception as e:
        return f"<h1>Erro ao adicionar estudante:</h1><p>{e}</p>", 500
    finally:
        if cursor:
            cursor.close()
        conn.close()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)
